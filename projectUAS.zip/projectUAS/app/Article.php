<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
    protected $fillable = ['user_id','category_id','name','description','image','created_at','updated_at'
    ];

    public function articleCategories(){
        return $this->hasOne(Category::class);
    }

    public function articleUser(){
        return $this->belongsTo(User::class);
    }



}
