<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Article;
use App\User;

class ArticleController extends Controller
{
    //menampilkan blog yang baru saja dibuat
    public function index(){
        $article = Article::all();
        return view('home', ['article' => $article]); 
              
    }

    //berfungsi untuk menghapus blog berdasarkan category_id
    public function deleteArticle($category_id){
        Article::where('id',$category_id)->delete();
        return redirect('/home')->with('status','Blog deleted successfully');
    }

}
