<?php

namespace App\Http\Controllers;

use App\Http\Middleware\CheckAdmin;
use App\Article;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

    public function index(){
       return view('home');      
    }

    //show article di welcome page
    public function showWelcome()
    {
        $article = Article::all();
        return view('welcome')->with('article', $article);

     
    } 
    
    //redirect ke create page
    public function create()
    {
        return view('create');
    }

    //redirect ke update page
    public function update()
    {
        return view('update');
    }

}
