<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Article;
use App\Category;

class CreateController extends Controller
{


    public function index()
    {
        return view('create');  
    }
  
    public function add(Request $req)
    {
        //fungsi ini untuk menampilkan hasil blog/article yang baru saja dibuat oleh user
        $req->validate([
            'name' => 'required',
            'category_id' => 'required',
            'image' => 'required|image|mimes:jpeg,png,gif,svg,jpg|max:2048',
            'description' => 'required',
        ]);
            
        $image = $req->image->getClientOriginalName() . '-' . time() . '.' . $req->image->extension();
        $req->image->move(public_path('image'), $image);
      
       
        Article::create([
        'name' => $req->name,
        'user_id' => auth()->id(),
        'category_id' => $req->category_id,
        'description' => $req->description,
        'image' => $image,
        ]);
        //kembali ke halaman home jika sudah di add dan menampilkan pop up message 
        return redirect('home')->with('status','Blog added successfully');       
    }


}
