<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class UserController extends Controller
{
    public function index()
    {
            $users = User::all();       
            $filter = $users->whereNotIn('role',"Admin");
            return view('user', ['users' => $filter]);      
    }

    public function deleteUser($user_id){
        User::where('id',$user_id)->delete();
        return redirect('/home')->with('status','Account deleted successfully');
    }

}
