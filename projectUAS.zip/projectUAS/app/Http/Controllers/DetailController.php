<?php

namespace App\Http\Controllers;

use App\Article;
use Illuminate\Http\Request;

class DetailController extends Controller
{

    public function show($id){

        $article = Article::where('id',$id)->get();
        return view('detail', ['article' => $article]);
    }
}
