<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    /*

    
 * Update user's profile
 *
 * @param  Request $request
 * @return \Illuminate\Contracts\Support\Renderable
 */
    //untuk menampilkan halaman edit profile
    public function edit(Request $request)
    {
        return view('update', [
            'user' => $request->user()
        ]);
    }

    //untuk melakukan update profile user
    public function update(Request $request)    
    {
    $request->validate([
    'name' => 'required|string',
    'email' => 'required|string|max:255|unique:users',
    'phone' => 'required|string|min:12',
            
     ]);
    $request->user()->update(
        $request->all()
    );

    
    return redirect('/home')->with('status','Profile updated successfully');
    }
}



   


    

