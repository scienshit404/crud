@extends('layouts.app')
@section('content')
<table class="table">
                {{csrf_field()}}
                <thead>
                    <tr>
                    <th scope="col">No</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Action</th>
                    </tr>
                   
                </thead>
                <tbody>
                @foreach($users as $i)
                    <tr>
                    <th scope="row">{{$i -> id}}</th>
                    <td>{{$i -> name}} </td>
                    <td>{{$i -> email}}</td>
                    <td>
                    <a href="/deleteUser/{{$i->id}}" type="button" class="btn btn-link">Delete</a>
                    </td>
                    </tr>
                @endforeach
                </tbody>
                </table>
@endsection