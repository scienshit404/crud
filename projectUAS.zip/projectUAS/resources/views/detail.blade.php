@extends('layouts.app')
@section('content')

<div class="container">


<div class="card mb-2 borderless "style="max-width: 900px;">
<div class="row no-gutters">
      <div class="col-md-9">
      @foreach($article as $item)
        <img src="/image/{{$item->image}}" class="card-img-top h-100">
      </div>
      <div class="col-md-8">
        <div class="card-body">
          <h1 class="card-title">{{$item->name}}</h1>
          <p class="card-text">{{$item->description}}</p>
          <a href="{{url()->previous()}}" class="btn btn-outline-dark btn-lg mb-5">Back</a>
        </div>
      </div>
      @endforeach
</div>
  </div>

</div>
@endsection