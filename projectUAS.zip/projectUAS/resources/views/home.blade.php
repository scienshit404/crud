@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>
        

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    Welcome  {{ Auth::user()->name }},
                    {{ __('You are logged in!') }}
                    <br>
                @if(Auth::user()->role =="User")
                
                <a href="/create">Create Blog</a>
                <a href="/update">Update Profile</a>  
                <br>
                
            <table class="table">
                {{csrf_field()}}
                <thead>
                    <tr>
                    <th scope="col">Title</th>
                    <th scope="col">Action</th>
                    </tr>
                   
                </thead>
                <tbody>
                @foreach($article as $item )
                    <tr>    
                    <td>
                    <a href="/detail/{{$item->id}}" type="button" class="btn btn-link">{{$item -> name}}</a>
                     </td>
                    <td>
                    <a href="/delete/{{$item->id}}" type="button" class="btn btn-link">Delete</a>
                    </td>
                    </tr>
                @endforeach
                </tbody>
                </table>
                @endif
                @if(Auth::user()->role == "Admin")
               <a href="/user">Manage User</a>
                @endif
                            
                </div>
            </div>
        </div>  
    </div>
</div>
@endsection
