
<?php $__env->startSection('content'); ?>
<table class="table">
                <?php echo e(csrf_field()); ?>

                <thead>
                    <tr>
                    <th scope="col">No</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Action</th>
                    </tr>
                   
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <th scope="row"><?php echo e($i -> id); ?></th>
                    <td><?php echo e($i -> name); ?> </td>
                    <td><?php echo e($i -> email); ?></td>
                    <td>
                    <a href="/deleteUser/<?php echo e($i->id); ?>" type="button" class="btn btn-link">Delete</a>
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\projectUAS\resources\views/user.blade.php ENDPATH**/ ?>