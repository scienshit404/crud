
<?php $__env->startSection('content'); ?>

<div class="container">


<div class="card mb-2 borderless "style="max-width: 900px;">
<div class="row no-gutters">
      <div class="col-md-9">
      <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img src="/image/<?php echo e($item->image); ?>" class="card-img-top h-100">
      </div>
      <div class="col-md-8">
        <div class="card-body">
          <h1 class="card-title"><?php echo e($item->name); ?></h1>
          <p class="card-text"><?php echo e($item->description); ?></p>
          <a href="<?php echo e(url()->previous()); ?>" class="btn btn-outline-dark btn-lg mb-5">Back</a>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\projectUAS\resources\views/detail.blade.php ENDPATH**/ ?>