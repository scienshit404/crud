
<?php $__env->startSection('content'); ?>

<div class="content px-5">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="/add" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Tittle :</label>
            <input type="text" placeholder="Enter tittle" class="form-control" name="name">
        </div>

        <div class="form-group">
        <label for="category_id">Category : </label>
        <select class="form-control" name="category_id">
        <option value="1">Beach</option>
        <option value="2">Mountain</option>
        </select>
    </div>
        <div class="form-group">
            <span>Browse Photos : </span>
            <input type="file" class="form-control-file" id="img" name="image" accept=".png, .jpg, .jpeg">
        </div>
        
        <div class="form-group">
            <label for="description">Story :</label>
            <textarea class="form-control" placeholder="Enter Description" rows="2" name="description"></textarea>
        </div>


        <button type="submit" class="btn btn-primary mt-2">Create</button>
    </form> 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\projectUAS\resources\views/create.blade.php ENDPATH**/ ?>