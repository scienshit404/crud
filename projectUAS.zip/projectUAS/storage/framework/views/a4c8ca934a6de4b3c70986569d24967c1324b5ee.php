<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>
        

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    Welcome  <?php echo e(Auth::user()->name); ?>,
                    <?php echo e(__('You are logged in!')); ?>

                    <br>
                <?php if(Auth::user()->role =="User"): ?>
                
                <a href="/create">Create Blog</a>
                <a href="/update">Update Profile</a>  
                <br>
                
            <table class="table">
                <?php echo e(csrf_field()); ?>

                <thead>
                    <tr>
                    <th scope="col">Title</th>
                    <th scope="col">Action</th>
                    </tr>
                   
                </thead>
                <tbody>
                <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>    
                    <td>
                    <a href="/detail/<?php echo e($item->id); ?>" type="button" class="btn btn-link"><?php echo e($item -> name); ?></a>
                     </td>
                    <td>
                    <a href="/delete/<?php echo e($item->id); ?>" type="button" class="btn btn-link">Delete</a>
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
                <?php endif; ?>
                <?php if(Auth::user()->role == "Admin"): ?>
               <a href="/user">Manage User</a>
                <?php endif; ?>
                            
                </div>
            </div>
        </div>  
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\projectUAS\resources\views/home.blade.php ENDPATH**/ ?>