<?php

use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'id' => '1',
            'name' => 'adminapp',
            'email' => 'adminapp@admin.com',
            'role' => 'Admin',
            'phone' => '085880778373',
            'password' => bcrypt('admin1234')
        ]);

        DB::table('users')->insert([
            'id' => '7',
            'name' => 'robby',
            'email' => 'robby@gmail.com',
            'role' => 'User',
            'phone' => '085880428374',
            'password' => bcrypt('12345678')
        ]);
    }
}
