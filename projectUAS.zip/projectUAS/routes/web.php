<?php

use App\Http\Controllers\HomeController;
use App\Http\Middleware\CheckAdmin;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');
//menampilkan blog di homepage yang sudah dibuat
Route::get('/', 'HomeController@showWelcome')->name('welcome');

//full story of blog
Route::get('/detail/{id}', 'DetailController@show');

//show tittle blog dan action delete untuk menghapus blog di halaman home
Route::get('/home', 'ArticleController@index');
Route::get('/delete/{category_id}', 'ArticleController@deleteArticle');

//redirect untuk create dan update di halaman user
Route::get('/create','HomeController@create');
Route::get('/update','HomeController@update');

//untuk create blog di user
Route::post('/add', 'CreateController@add');

//untuk mengupdate profil dari user
Route::get('/update', 'ProfileController@edit')->name('update');
Route::patch('/update', 'ProfileController@update')->name('update');

//route buat admin untuk menampilkan data user dan delete data user
Route::get('/user','UserController@index');
Route::get('/deleteUser/{user_id}', 'UserController@deleteUser');











